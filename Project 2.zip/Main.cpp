// Author: Isaac Ocegueda
// Date: 02/06/2023
// Description: Project 2

#include <iostream>
#include <iomanip>
#include <string>
#include <cmath>
using namespace std;

// function to calculate interest without monthly payments
// takes the initial amount and interest rate entered and multiplies together with the rate in percent form
double CalculateWithoutMonthly(double initialAmount, double interestRate) {
    return initialAmount * (interestRate / 100);
}
// function to calculate interst on monthly compound
// takes the initial amount, adds monthly deposits, and multiplies with year rate divided by 12 months
double CalculateWithMonthly(double initialAmount, double monthlyDeposit, double interestRate) {
    return (initialAmount + monthlyDeposit) * ((interestRate / 100) / 12);
}

//function to print both tables and calculate the total amounts
void PrintDetails(int year, double initialAmount, double interestRate, double monthlyDeposit) {
    double yearEndBalance;              // place holder for balance at the end of year
    double interestEarned;              // place holder for total interest earned
    double balance = initialAmount;     // place holder for balance, starts with initial amount entered
    double interestPerMonth;            // place holder to calculate interest earned monthly

    // print out of the tables formed into 3 right-aligned columns
    cout << " Balance and Interest Without Additional Monthly Deposits" << endl;
    cout << "==================================================================" << endl;
    cout << right << setw(6) << "Year"
        << right << setw(25) << "Year End Balance"
        << right << setw(32) << "Year End Earned Interest" << endl;
    cout << "------------------------------------------------------------------" << endl;
    for (int i = 0; i < year; ++i) {        // loop to print depending on number of years entered
        yearEndBalance = initialAmount + CalculateWithoutMonthly(initialAmount, interestRate);
        interestEarned = CalculateWithoutMonthly(initialAmount, interestRate);
        cout << right << setw(6) << i + 1 << fixed << setprecision(2) 
            << setw(21) << "$" << yearEndBalance
            << setw(28) << "$" << interestEarned << endl;
        initialAmount = yearEndBalance;
    }
    cout << endl << endl;

    cout << " Balance and Interest With Additional Monthly Deposits" << endl;
    cout << "==================================================================" << endl;
    cout << right << setw(6) << "Year"
        << right << setw(25) << "Year End Balance"
        << right << setw(32) << "Year End Earned Interest" << endl;
    cout << "------------------------------------------------------------------" << endl;
    for (int i = 0; i < year; i++) {    // double loop to compound interest every month
        interestPerMonth = 0;
        interestEarned = 0;
        for (int j = 0; j < 12; j++) {  // loops 12 times, adds monthly deposit to balance, and adds total interest
            interestPerMonth =+ CalculateWithMonthly(balance, monthlyDeposit, interestRate);
            balance += interestPerMonth;
            balance += monthlyDeposit;
            interestEarned += interestPerMonth;
        }
        cout << right << setw(6) << i + 1;
        cout << right << fixed << setprecision(2);
        cout << setw(18) << "$" << right << balance;
        cout << setw(29) << "$" << right << interestEarned << endl;
        initialAmount = yearEndBalance;
    }
}

// main function
int main() {
    int years = 0;              // initialize everything to 0
    double initialAmount = 0;
    double interestRate = 0;
    double monthlyDeposit = 0;

    // output header and ask for user input on variables
    // each input is checked to ensure positive real numbers are entered
    cout << "********** Data Input *********" << endl;
    cout << "Please enter an initial investment amount:";
    cin >> initialAmount;
    while (initialAmount <= 0) {
        cout << "Please enter a positive number" << endl;
        cin >> initialAmount;
    }
    cout << "Please enter monthly deposit amount:";
    cin >> monthlyDeposit;
    while (monthlyDeposit <= 0) {
        cout << "Please enter a positive number" << endl;
        cin >> monthlyDeposit;
    }
    cout << "Please enter the annual interest rate:";
    cin >> interestRate;
    while (interestRate <= 0) {
        cout << "Please enter a positive number" << endl;
        cin >> interestRate;
    }
    cout << "Please enter number of years: ";
    cin >> years;
    while (years <= 0) {
        cout << "Please enter a positive number" << endl;
        cin >> years;
    }
    cout << endl;
    // prints out everything again for user to see their input
    cout << "You Entered:" << endl;
    cout << "Initial Investment Amount: $" << initialAmount << endl;
    cout << "Monthly Deposit: $" << monthlyDeposit << endl;
    cout << "Annual Interest: %" << interestRate << endl;
    cout << "Number of Years: " << years << endl;
    system("pause");    // waits for user to type a key to continue
    
    // calls the function to print the tables using the entered data
    PrintDetails(years, initialAmount, interestRate, monthlyDeposit);
    cout << endl << endl;

    // thank you message for user
    cout << "Thank you for using our savings calculator!" << endl;

	return 0;
}